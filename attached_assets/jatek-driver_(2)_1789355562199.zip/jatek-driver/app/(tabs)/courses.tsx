import { Feather } from "@expo/vector-icons";
import { useQuery } from "@tanstack/react-query";
import { useRouter } from "expo-router";
import React, { useState } from "react";
import { FlatList, Pressable, RefreshControl, StyleSheet, Text, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useColors } from "@/hooks/useColors";
import { getErrorMessage, listMyOrders, type Order, type OrderStatus } from "@/lib/api";
import { addMoney, formatMad } from "@/lib/money";

const STATUS_LABEL: Record<OrderStatus, string> = {
  pending: "En attente",
  assigned: "Assignée",
  accepted: "Acceptée",
  confirmed: "Confirmée",
  preparing: "Préparation",
  ready: "Prête",
  picked_up: "Acceptée",
  arrived_pickup: "Au restaurant",
  driver_at_restaurant: "Au restaurant",
  en_route: "En route",
  out_for_delivery: "À destination",
  delivered: "Livrée",
  cancelled: "Annulée",
  unknown: "À actualiser",
};

const STATUS_COLOR: Record<OrderStatus, string> = {
  pending: "#F59E0B",
  assigned: "#00B4D8",
  accepted: "#00B4D8",
  confirmed: "#00B4D8",
  preparing: "#F59E0B",
  ready: "#00B4D8",
  picked_up: "#8B5CF6",
  arrived_pickup: "#F59E0B",
  driver_at_restaurant: "#F59E0B",
  en_route: "#8B5CF6",
  out_for_delivery: "#F59E0B",
  delivered: "#9BA617",
  cancelled: "#EF4444",
  unknown: "#6B7280",
};

const FILTERS = ["Toutes", "Actives", "Terminées", "Annulées"] as const;
type Filter = typeof FILTERS[number];

export default function CoursesScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const [filter, setFilter] = useState<Filter>("Toutes");

  const { data = [], isRefetching, isError, error, refetch } = useQuery({
    queryKey: ["my-orders"],
    queryFn: listMyOrders,
    refetchInterval: 30_000,
  });

  const filtered = data.filter((o) => {
    if (filter === "Actives") return !["delivered", "cancelled"].includes(o.status);
    if (filter === "Terminées") return o.status === "delivered";
    if (filter === "Annulées") return o.status === "cancelled";
    return true;
  });

  return (
    <View style={[styles.root, { backgroundColor: colors.background }]}>
      <View style={[styles.filterRow, { paddingTop: insets.top + 8, backgroundColor: colors.background, borderBottomColor: colors.border }]}>
        {FILTERS.map((f) => {
          const active = filter === f;
          return (
            <Pressable key={f} onPress={() => setFilter(f)} style={[styles.filterBtn, { backgroundColor: active ? colors.primary : colors.muted, borderRadius: 20 }]}>
              <Text style={{ color: active ? colors.primaryForeground : colors.mutedForeground, fontFamily: "Inter_600SemiBold", fontSize: 12 }}>{f}</Text>
            </Pressable>
          );
        })}
      </View>

      <FlatList
        data={filtered}
        keyExtractor={(o) => o.id}
        contentContainerStyle={{ paddingHorizontal: 16, paddingTop: 16, paddingBottom: insets.bottom + 80 }}
        refreshControl={<RefreshControl refreshing={isRefetching} onRefresh={refetch} tintColor={colors.primary} />}
        renderItem={({ item }) => <CourseCard order={item} colors={colors} onPress={() => router.push(`/order/${item.id}`)} />}
        ItemSeparatorComponent={() => <View style={{ height: 10 }} />}
        ListEmptyComponent={
          <View style={styles.empty}>
            <Feather name={isError ? "wifi-off" : "package"} size={36} color={colors.mutedForeground} />
            <Text style={[styles.emptyText, { color: colors.mutedForeground, fontFamily: "Inter_500Medium" }]}>
              {isError ? getErrorMessage(error, "Impossible de charger vos courses.") : "Aucune course à afficher."}
            </Text>
            {isError && (
              <Pressable
                onPress={() => void refetch()}
                style={[styles.retryButton, { backgroundColor: colors.primary, borderRadius: colors.radius }]}
              >
                <Text style={{ color: colors.primaryForeground, fontFamily: "Inter_700Bold" }}>Réessayer</Text>
              </Pressable>
            )}
          </View>
        }
      />
    </View>
  );
}

function CourseCard({ order, colors, onPress }: { order: Order; colors: ReturnType<typeof useColors>; onPress: () => void }) {
  const statusColor = STATUS_COLOR[order.status] ?? colors.mutedForeground;
  const isActive = !["delivered", "cancelled"].includes(order.status);
  return (
    <Pressable onPress={onPress} style={({ pressed }) => [styles.card, { backgroundColor: colors.card, borderColor: isActive ? colors.primary + "40" : colors.border, borderRadius: colors.radius, opacity: pressed ? 0.9 : 1 }]}>
      <View style={styles.cardTop}>
        <View>
          <Text style={[styles.code, { color: colors.mutedForeground, fontFamily: "Inter_500Medium" }]}>{order.code}</Text>
          <Text style={[styles.restaurant, { color: colors.foreground, fontFamily: "Inter_700Bold" }]} numberOfLines={1}>{order.restaurantName}</Text>
        </View>
        <View style={{ alignItems: "flex-end" }}>
          <View style={[styles.statusPill, { backgroundColor: statusColor + "20" }]}>
            <Text style={{ color: statusColor, fontFamily: "Inter_600SemiBold", fontSize: 11 }}>{STATUS_LABEL[order.status]}</Text>
          </View>
          <Text style={[styles.price, { color: colors.success, fontFamily: "Inter_700Bold" }]}>{formatMad(addMoney(order.driverEarningsMad, order.tipMad))} DH</Text>
        </View>
      </View>
      <View style={[styles.divider, { backgroundColor: colors.border }]} />
      <View style={styles.route}>
        <Feather name="shopping-bag" size={13} color={colors.info} />
        <Text style={[styles.address, { color: colors.mutedForeground, fontFamily: "Inter_400Regular" }]} numberOfLines={1}>{order.pickupAddress}</Text>
      </View>
      <View style={styles.route}>
        <Feather name="map-pin" size={13} color={colors.primary} />
        <Text style={[styles.address, { color: colors.mutedForeground, fontFamily: "Inter_400Regular" }]} numberOfLines={1}>{order.dropoffAddress}</Text>
      </View>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  filterRow: { flexDirection: "row", gap: 8, paddingHorizontal: 16, paddingBottom: 12, borderBottomWidth: 1 },
  filterBtn: { paddingHorizontal: 14, paddingVertical: 8 },
  card: { padding: 14, borderWidth: 1, gap: 10 },
  cardTop: { flexDirection: "row", justifyContent: "space-between", alignItems: "flex-start" },
  code: { fontSize: 11, letterSpacing: 0.5 },
  restaurant: { fontSize: 15, marginTop: 2 },
  statusPill: { paddingHorizontal: 8, paddingVertical: 4, borderRadius: 8, marginBottom: 4 },
  price: { fontSize: 16 },
  divider: { height: 1 },
  route: { flexDirection: "row", alignItems: "center", gap: 8 },
  address: { flex: 1, fontSize: 13 },
  empty: { alignItems: "center", paddingVertical: 60, gap: 12 },
  emptyText: { fontSize: 14 },
  retryButton: { paddingHorizontal: 18, paddingVertical: 10 },
});
